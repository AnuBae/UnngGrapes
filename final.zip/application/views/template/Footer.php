</body>
<!-- footer start -->
<?php if ($this->uri->segment(1) == '') : ?>
    <footer class="footer-fluid fixed-bottom mt-auto py-3 text-center bg-secondary">
    <?php else : ?>
        <footer class="footer-fluid mt-auto py-3 text-center bg-secondary">
        <?php endif; ?>
        <a class="text-dark" target="_blank" href="https://icons8.com/icon/119752/grapes">Grapes</a> icon by <a class="text-dark" target="_blank" href="https://icons8.com">Icons8</a>

        <div class="container">
            <span class=""> Created with <i class="bi bi-suit-heart-fill text-danger"></i> by <a class="text-dark fw-bold" target="_blank" href="https://www.instagram.com/mansyahhuda/">Rusmansyah</a>
            </span>
        </div>
        </footer>

        <!-- footer end -->

        </html>